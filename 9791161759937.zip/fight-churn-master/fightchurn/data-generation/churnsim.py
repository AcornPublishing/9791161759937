print('\n*** Module data-generation is deprecated in fightchurn 1.1 (August 2023) - please use the churnsim module instead.')
print('The ChurnSim White Paper is available now: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4540160')
